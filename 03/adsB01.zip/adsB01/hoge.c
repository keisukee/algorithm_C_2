#include <stdlib.h>
#include <stdio.h>

int main(void) {
  printf("%d\n", rand ());
  printf("%d\n", RAND_MAX);
  return 0;
}
